from helper import *
from data import *

def main():
    try:
        #get config
        help = helper()
        config = help.readConfig()
        url = config['url']
        salePerCent = float(config['salePerCent'])
        filename = config['filename']
        startPage = int(config['startPage'])
        endPage = int(config['endPage'])
        #write csv header
        csv = data(filename=filename)
        csv.writeHeader()
        #get total pages
        if endPage < startPage:
            print("End page not < start page")
            return
        if endPage > 50:
            print("Only can get 50 pages")
            return
        for i in range(startPage, endPage + 1):
            print("=> Fetching page: {}".format(i))
            getpage = helper(url=url)
            childUrls = getpage.fetchPage(page=i)
            if len(childUrls) > 0:
                for childUrl in childUrls:
                    print("=> Fetching url: {}".format(childUrl))
                    dataC = helper(url=childUrl)
                    dataA = dataC.getData()
                    if dataA['status'] == 'fail':
                        print("==> Product not found")
                        continue
                    salePrice = float(dataA['retailPrice']) - ((float(dataA['retailPrice']) * salePerCent) / 100)
                    salePrice = round(salePrice, 2)
                    published = 1
                    wr = data(
                        sku=dataA['isbn'],
                        name=dataA['title'],
                        published = published,
                        salePrice=salePrice,
                        regularPrice=dataA['retailPrice'],
                        short_description = dataA['short_description'],
                        description=dataA['description'],
                        image=dataA['image'],
                        filename=filename
                    )
                    wr.writeRow()
    except Exception as e:
        print(e)
    except KeyboardInterrupt:
        print("STOP!")
        
if __name__ == '__main__':
    main()