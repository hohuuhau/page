import json
import requests
import urllib3
import re
import sys
from bs4 import BeautifulSoup
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import json
class helper:

    def __init__(self, url = None):
        self.url = url
    def readConfig(self):
        data = None
        try:
            with open('config.json') as f:
                data = json.load(f)
        except Exception as e:
            print(e)
        finally:
            return data
    def fetchPage(self, page=1):
        dataUrl = []
        baseUrl = "https://biblestore.com"
        maxPage = None
        try:
            # proxies = {
            #     "http": "127.0.0.1:8888",
            #     "https": "127.0.0.1:8888",
            #     }

            if(page != 1):
                url = self.url + "?page=" + str(page)
            else:
                url = self.url
            res = requests.get(url, verify=False)
            if res.status_code != 200:
                print("Can't fetch page")
            else:
                soup = BeautifulSoup(res.text, 'html.parser')
                wrap = soup.find("div", {'class': 'grid-uniform'}).findAll('div', recursive=False)
                if len(wrap) <= 0:
                    print("No product in page")
                    sys.exit(0)
                else:
                    for child in wrap:
                        pTile = child.find("div", {'class': 'product-title'}).find('a', recursive=False, href=True)
                        dataUrl.append(baseUrl + pTile['href'])
        except Exception as e:
            print(e)
        finally:
            # return dataUrl, maxPage
            return dataUrl
    def getData(self):  
        data = dict([
            ("retailPrice", ""),
            ("image", ""),
            ("title", ""),
            ("isbn", ""),
            ("status", ""),
            ("description", ""),
            ("short_description", "")
        ])

        try:
            debug = False
            #default value
            url = self.url
            res = requests.get(url, verify=False)
            if "Oops! The page you&#39;re looking for cannot be found" in res.text:
                data['status'] = "fail"
                return data
                
            image = ""
            title = ""
            isbn = ""
            author = ""
            description = ""
            short_description = ""
            retailPrice = 0
            html = res.text

            soup = BeautifulSoup(html, 'html.parser')
            rentailDiv = soup.find('span', {'id': 'ComparePrice'})
            if rentailDiv != None:
                SretailPrice = rentailDiv.string.strip().replace('$', '')
                retailPrice = SretailPrice
            else:
                retailPrice = 0
            if debug:
                print(retailPrice)

            #
            wrap_short_description = re.findall('<script id="product-json-(.*?)<\/script>', html)
            if len(wrap_short_description) > 0:
                short_description_w = re.findall("\"description\":\"(.*?)\",\"", wrap_short_description[0])
                short_description = short_description_w[0]
                
            if debug:
                print(short_description)
            # short_description = "<table " + short_description[0].strip() + "<\/table>"

            title = re.findall('<meta property=\"og:title\" content=\"(.*?)\"', html)
            if len(title) > 0:
                title = title[0].strip()
            if debug:
                print(title)
            
            #
            isbn = soup.find('span', {'class': 'variant-sku'})
            if isbn != None:
                isbn = isbn.string.strip()
            else:
                import time
                isbn = int(time.time())
            
            #
            description = short_description

            
            img = soup.find('a', {'id': 'Zoom-1'})
            if img != None:
                image = img['data-image']
            if debug:
                print(img)

            # print()
            # sys.exit(0)
            data['retailPrice'] = retailPrice
            data['image'] = image
            data['title'] = title
            data['isbn'] = isbn
            data['description'] = description
            data['short_description'] = short_description
            data['status'] = "ok"
        except Exception as e:
            print(e)
        finally:
            return data


# url = "https://biblestore.com/collections/translation-niv"
# help = helper(url=url)
# data = help.fetchPage(page=2)
# print(data)
# print(len(data))
# url = "https://biblestore.com/collections/master-category-bibles/products/csb-incourage-devotional-bible-navy-genuine-leather-9781535924948"
# help = helper(url=url)
# data = help.getData()
# print((data))